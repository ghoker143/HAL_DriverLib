//
// Created by a2683 on 5/7/2022.
//

#ifndef GUI_DRIVER_TEST_TOUCH_H
#define GUI_DRIVER_TEST_TOUCH_H
#include "main.h"
#include "LCD.h" //borrow the delay func
#define CPU_FREQUENCY_MHZ 72

void XPT2046_TouchInit(void);
void XPT2046_SPI_WriteOneByte(uint8_t cmd);
uint8_t XPT2046_ReadXY(u16 *x,u16 *y);
uint8_t XPT2046_ReadXY_Filtered(u16 *x,u16 *y);
uint8_t XPT2046_Read_PysXY(u16 *x,u16 *y);



#endif //GUI_DRIVER_TEST_TOUCH_H
