//
// Created by a2683 on 5/7/2022.
// it used a soft SPI because the design of my board is really weird
// you can use NVIC on pen pin
//
#include "touch.h"

void XPT2046_SPI_WriteOneByte(uint8_t cmd)
{
    uint8_t i;
    for(i=0;i<8;i++)
    {
        HAL_GPIO_WritePin(TCLK_GPIO_Port,TCLK_Pin,GPIO_PIN_RESET);; //低电平写
        if(cmd&0x80)HAL_GPIO_WritePin(TDIN_GPIO_Port,TDIN_Pin,GPIO_PIN_SET);
        else HAL_GPIO_WritePin(TDIN_GPIO_Port,TDIN_Pin,GPIO_PIN_RESET);
        cmd<<=1;
        HAL_GPIO_WritePin(TCLK_GPIO_Port,TCLK_Pin,GPIO_PIN_SET);; //高电平读,保证数据线稳定
    }
}


/*
函数功能:  读2个字节
说明: 读取16位数据，最低4位数据无效，有效数据是高12位
*/
uint16_t XPT2046_ReadData(uint8_t cmd)
{
    uint16_t data;
    uint8_t i;
    HAL_GPIO_WritePin(TCS_GPIO_Port,TCS_Pin,GPIO_PIN_RESET);;
    HAL_GPIO_WritePin(TDIN_GPIO_Port,TDIN_Pin,GPIO_PIN_RESET);;
    HAL_GPIO_WritePin(TCLK_GPIO_Port,TCLK_Pin,GPIO_PIN_RESET);;
    XPT2046_SPI_WriteOneByte(cmd);

    delay_us(8);

    HAL_GPIO_WritePin(TCLK_GPIO_Port,TCLK_Pin,GPIO_PIN_RESET);;
    delay_us(1);
    HAL_GPIO_WritePin(TCLK_GPIO_Port,TCLK_Pin,GPIO_PIN_SET);;

    for(i=0;i<16;i++)
    {
        HAL_GPIO_WritePin(TCLK_GPIO_Port,TCLK_Pin,GPIO_PIN_RESET);
        HAL_GPIO_WritePin(TCLK_GPIO_Port,TCLK_Pin,GPIO_PIN_SET);
        data<<=1;
        if(HAL_GPIO_ReadPin(DOUT_GPIO_Port,DOUT_Pin)==GPIO_PIN_SET)data|=0x01;
    }
    data>>=4; //丢弃最低4位

    HAL_GPIO_WritePin(TCS_GPIO_Port,TCS_Pin,GPIO_PIN_SET);
    return data;
}

/*
for purpose here, a generic 2046 should be giving orders as follow
0x90 : get adc value of y axis
0xD0 : get adc value of x axis

for a resistive screens, you should change value here to calibrate. the steps of calibrating is as follow
//1. get maxium and minium reading of x axis and y axis

//2.figure the resolution of you own screen and transfer the original readings to it. it's a linar relationship, I'm sure you can figure it out
*/

uint8_t XPT2046_Read_PysXY(u16 *x,u16 *y)
{
    if(HAL_GPIO_ReadPin(PEN_GPIO_Port,PEN_Pin)==GPIO_PIN_RESET)
    {
        *x=XPT2046_ReadData(0xD0);
        *y=XPT2046_ReadData(0x90);
        return 1;
    }
    return 0;
}

uint8_t XPT2046_ReadXY(u16 *x,u16 *y)
{
    if(HAL_GPIO_ReadPin(PEN_GPIO_Port,PEN_Pin)==GPIO_PIN_RESET)
    {
        *x=240-(XPT2046_ReadData(0xD0)-220)/15.375;
        *y=(XPT2046_ReadData(0x90)-190)/11.128;
        return 1;
    }
    return 0;
}

uint8_t XPT2046_ReadXY_Filtered(u16 *x,u16 *y)
{
    uint16_t x1,y1,x2,y2;
    if(XPT2046_ReadXY(&x1,&y1))
    {
        if(XPT2046_ReadXY(&x2,&y2))
        {
            if(((x2<=x1&&x1<x2+10)||(x1<=x2&&x2<x1+10)) //adjast the fixed value to meet you demand of precision
               &&((y2<=y1&&y1<y2+10)||(y1<=y2&&y2<y1+10)))
            {
                *x=(x1+x2)/2;
                *y=(y1+y2)/2;
                return 1;
            } else return 0;
        }
        return 0;
    }
    return 0;
}


