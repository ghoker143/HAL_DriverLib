//
// Created by a2683 on 11/28/2021.
//

#include <stdio.h>
#include <string.h>
#include "MP3.h"
#include "fatfs.h"

#define BUFFER_SIZE 	32

uint8_t mp3Buffer[BUFFER_SIZE];
uint32_t mp3FileSize;
uint32_t readBytes;
uint16_t cnt = 0;

uint8_t isPlaying = 0;
uint8_t isFileOpen = 0;

FATFS fs;
FIL mp3File;
extern UART_HandleTypeDef huart1;

uint8_t MP3_FileScan()
{
    volatile uint8_t len=0;
    uint16_t* MP3Index;
    FRESULT fresult;
    FILINFO MP3FileInfo;
    uint8_t CurrentIndex;
    WORD Temp;
    DIR MP3Dir;
    fresult=f_opendir(&MP3Dir,"0:/MUSIC");
    if(fresult==FR_OK)
    {
        CurrentIndex=0;
        while(1)
        {
            Temp=MP3Dir.index;
            fresult=f_readdir(&MP3Dir,&MP3FileInfo);
            if(fresult!=FR_OK||MP3FileInfo.fname[0]==0)return CurrentIndex;
            len=0;
            while(MP3FileInfo.fname[len]!=0){len++;}
            if(MP3FileInfo.fname[len-1]==51)
            {
                char NAME[len+9];
                sprintf(NAME,"0:/MUSIC/");
                for(int hh=9;hh<=len+9;hh++){NAME[hh]=MP3FileInfo.fname[hh-9];}
                HAL_UART_Transmit(&huart1,NAME,len+9,1000);
                HAL_UART_Transmit(&huart1,"\r\n",2,1000);
            };
            MP3Index[CurrentIndex]=Temp;
            CurrentIndex++;
        }
    }
    return 0;
}


/* Initialize VS1053 & Open a file */
uint8_t MP3_Init()
{
    /* Initialize VS1053 */
    if(!VS1053_Init()) return 0;

    /* Mount SD Card */
    if(f_mount(&fs, "0:", 0) != FR_OK) return 0;

    return 1;
}

uint8_t MP3_Play(const char *filename)
{
    if(isPlaying) MP3_Stop();
    if(!VS1053_SetMode(0x4800)) return 0;	/* SM LINE1 | SM SDINEW */
    if(!VS1053_AutoResync()) return 0;		/* AutoResync */
    if(!VS1053_SetDecodeTime(0)) return 0;	/* Set decode time */
    if(!VS1053_SetVolume( 0x3F, 0x3F )) return 0;	/* Small number is louder */

    /* Open file to read */
    if(f_open(&mp3File,filename, FA_READ)!=FR_OK)return 0;

    /* Get the file size */
    mp3FileSize = f_size(&mp3File);

    /* Set flags */
    isFileOpen = 1;
    isPlaying = 1;

    return 1;
}

void MP3_Stop(void)
{
    /* Refer to page 49 of VS1053 datasheet */

    uint16_t mode;
    VS1053_SendEndFill(2052);	/* send endfill bytes */
    VS1053_SetMode(0x4808);		/* SM LINE1 | SM SDINEW | SM CANCEL */
    VS1053_SendEndFill(32);		/* send endfill bytes */
    HAL_Delay(100);
    VS1053_GetMode(&mode);		/* get mode value */
    if((mode & 0x08) != 0x0)	/* if SM CANCEL is not clear, soft reset */
    {
        VS1053_SoftReset();
    }

    f_close(&mp3File);
    isPlaying = 0;			/* Stop flag */
    isFileOpen = 0;			/* Close flag */
}

void MP3_Pause(void)
{
    if(isPlaying) isPlaying = 0;
}

void MP3_Resume(void)
{
    if(!isPlaying) isPlaying = 1;
}

/* Send mp3 buffer to VS1053 */
void MP3_Feeder(void)
{
    if(!isPlaying || !isFileOpen) return;

    if(mp3FileSize > BUFFER_SIZE)
    {
        /* Fill the buffer */
        f_read(&mp3File, mp3Buffer, BUFFER_SIZE, (void*)&readBytes);

        /* Tx buffer */
        VS1053_SdiWrite32( mp3Buffer );

        /* bytes to send */
        mp3FileSize -= BUFFER_SIZE;
    }
    else
    {
        /* Read left bytes */
        f_read(&mp3File, mp3Buffer, mp3FileSize, (void*)&readBytes);

        /* Tx buffer */
        for (cnt = 0; cnt < mp3FileSize; cnt++)
        {
            while(!VS1053_SdiWrite(*(mp3Buffer + cnt)));
        }

        /* Stop when played the whole file */
        MP3_Stop();
    }
}
