//
// Created by a2683 on 11/28/2021.
//

#ifndef CPROJECT_MP3_H
#define CPROJECT_MP3_H

#include "stm32f1xx_hal.h"
#include "VS1053.h"

/* Functions */
uint8_t MP3_Init(void);
uint8_t MP3_Play(const char *filename);
void MP3_Stop(void);
void MP3_Pause(void);
void MP3_Resume(void);
void MP3_Feeder(void);
uint8_t MP3_FileScan();
/* Flags */
extern uint8_t isPlaying;
extern uint8_t isFileOpen;

#endif //CPROJECT_MP3_H
