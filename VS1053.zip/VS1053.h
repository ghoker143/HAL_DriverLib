//
// Created by a2683 on 11/28/2021.
//

#ifndef CPROJECT_VS1053_H
#define CPROJECT_VS1053_H

#include "stm32f1xx_hal.h"
#include "main.h"

#define XCS_HIGH	HAL_GPIO_WritePin(XCS_GPIO_Port, XCS_Pin, GPIO_PIN_SET)
#define XCS_LOW		HAL_GPIO_WritePin(XCS_GPIO_Port, XCS_Pin, GPIO_PIN_RESET)
#define XDCS_HIGH	HAL_GPIO_WritePin(XDCS_GPIO_Port, XDCS_Pin, GPIO_PIN_SET)
#define XDCS_LOW	HAL_GPIO_WritePin(XDCS_GPIO_Port, XDCS_Pin, GPIO_PIN_RESET)
#define XRST_HIGH	HAL_GPIO_WritePin(XRST_GPIO_Port, XRST_Pin, GPIO_PIN_SET)
#define XRST_LOW	HAL_GPIO_WritePin(XRST_GPIO_Port, XRST_Pin, GPIO_PIN_RESET)
#define VS1053_DREQ_PORT DREQ_GPIO_Port
#define VS1053_DREQ_PIN DREQ_Pin
#define HSPI_VS1053			&hspi1
#define VS1053_WRITE_CMD	0x02;
#define VS1053_READ_CMD		0x03;
#define I2S_CONFIG			0XC040
#define GPIO_DDR			0XC017
#define GPIO_IDATA			0XC018
#define GPIO_ODATA			0XC019

void VS1053_SPK(uint8_t sw);
uint8_t VS1053_Init();
uint8_t VS1053_Reset();
uint8_t VS1053_SoftReset();
uint8_t VS1053_SetVolume(uint8_t volumeLeft, uint8_t volumeRight);
uint8_t VS1053_SetMode(uint16_t mode);
uint8_t VS1053_GetMode(uint16_t *mode);
uint8_t VS1053_AutoResync();
uint8_t VS1053_SetDecodeTime(uint16_t time);
uint8_t VS1053_SendEndFill(uint16_t num);
uint8_t VS1053_IsBusy();
uint8_t VS1053_SciWrite(uint8_t address, uint16_t input);
uint8_t VS1053_SciRead(uint8_t address, uint16_t *res);
uint8_t VS1053_SdiWrite(uint8_t input);
uint8_t VS1053_SdiWrite32(uint8_t *input32);

#endif //CPROJECT_VS1053_H
