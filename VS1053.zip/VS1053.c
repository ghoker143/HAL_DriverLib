//
// Created by a2683 on 11/28/2021.
//

#include "VS1053.h"

const uint8_t VS1053_REG_BASE		= 0x00;
const uint8_t VS1053_REG_MODE   	= 0x00;
const uint8_t VS1053_REG_STATUS 	= 0x01;
const uint8_t VS1053_REG_BASS 		= 0x02;
const uint8_t VS1053_REG_CLOCKF 	= 0x03;
const uint8_t VS1053_REG_DECODE_TIME = 0x04;
const uint8_t VS1053_REG_AUDATA 	= 0x05;
const uint8_t VS1053_REG_WRAM 		= 0x06;
const uint8_t VS1053_REG_WRAMADDR 	= 0x07;
const uint8_t VS1053_REG_HDAT0 		= 0x08;
const uint8_t VS1053_REG_HDAT1 		= 0x09;
const uint8_t VS1053_REG_AIADDR 	= 0x0A;
const uint8_t VS1053_REG_VOL 		= 0x0B;
const uint8_t VS1053_REG_AICTRL0 	= 0x0C;
const uint8_t VS1053_REG_AICTRL1 	= 0x0D;
const uint8_t VS1053_REG_AICTRL2 	= 0x0E;
const uint8_t VS1053_REG_AICTRL3 	= 0x0F;
uint8_t endFillByte;
extern SPI_HandleTypeDef hspi1;

uint8_t VS1053_Init()
{
    uint16_t status = 0;

    XCS_HIGH;		    /* XCS High */
    XDCS_HIGH;		    /* XDCS High */
    VS1053_Reset();     /* Hard Reset */

    /* x 1.0 Clock, 12MHz / 7, SPI Baudrate should be less than 1.75MHz */
    (HSPI_VS1053)->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32;  /* 42MHz / 32 = 1.31MHz */
    if(HAL_SPI_Init(HSPI_VS1053) != HAL_OK) return 0;

    /* Read Status to check SPI */
    if(!VS1053_SciRead(VS1053_REG_STATUS, &status)) return 0;
    if(((status >> 4) & 0x0F) != 0x04) return 0;

    /* MP3 Mode GPIO configuration */
    if(!VS1053_SciWrite(VS1053_REG_WRAMADDR, 0xC017)) return 0; /* GPIO direction */
    if(!VS1053_SciWrite(VS1053_REG_WRAM, 3)) return 0;
    if(!VS1053_SciWrite(VS1053_REG_WRAMADDR, 0xC019)) return 0; /* GPIO output */
    if(!VS1053_SciWrite(VS1053_REG_WRAM, 0)) return 0;

    /* Soft reset */
    if(!VS1053_SoftReset()) return 0;

    /* x3.0 Clock, 36MHz / 7, SPI Baudrate should be less than 5.14MHz */
    if(!VS1053_SciWrite(VS1053_REG_CLOCKF, 0x6000)) return 0;

    (HSPI_VS1053)->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;  /* 42MHz / 16 = 2.625MHz */
    if(HAL_SPI_Init(HSPI_VS1053) != HAL_OK) return 0;

    /* Read Status to check SPI */
    if(!VS1053_SciRead(VS1053_REG_STATUS, &status)) return 0;
    if(((status >> 4) & 0x0F) != 0x04) return 0;

    /* Read endFill Byte */
    uint16_t regVal;
    if(!VS1053_SciWrite(VS1053_REG_WRAMADDR, 0x1E06)) return 0;	/* endFill */
    if(!VS1053_SciRead(VS1053_REG_WRAM, &regVal)) return 0;
    endFillByte = regVal & 0xFF;

    return 1;
}

/* Hard reset */
uint8_t VS1053_Reset()
{
    uint8_t retry=0;
    XRST_LOW;
    HAL_Delay(20);
    XDCS_HIGH;//ȡ�����ݴ���
    XCS_HIGH;//ȡ�����ݴ���
    XRST_HIGH;
    while(HAL_GPIO_ReadPin(VS1053_DREQ_PORT, VS1053_DREQ_PIN) == GPIO_PIN_RESET&&retry<200)//�ȴ�DREQΪ��
    {
        retry++;
        HAL_Delay(50);
    };
    HAL_Delay(20);
    if(retry>=200)return 1;
    else return 0;
}
/* Soft reset */

uint8_t VS1053_SoftReset()
{
    uint8_t retry=0;
    uint16_t RETURN;
    while (HAL_GPIO_ReadPin(VS1053_DREQ_PORT, VS1053_DREQ_PIN) == GPIO_PIN_RESET); 					//�ȴ�������λ����
    VS1053_SdiWrite(0Xff);//��������
    retry=0;

    while(VS1053_SciRead(VS1053_REG_BASE,&RETURN)==1&&RETURN!=0x0800)	// ������λ,��ģʽ
    {
        VS1053_SciWrite(VS1053_REG_BASE,0x0804); // ������λ,��ģʽ
        HAL_Delay(2);//�ȴ�����1.35ms
        if(retry++>100) return 0;
    }
    while (HAL_GPIO_ReadPin(VS1053_DREQ_PORT, VS1053_DREQ_PIN) == GPIO_PIN_RESET); 	//�ȴ�������λ����
    retry=0;

    while(VS1053_SciRead(VS1053_REG_CLOCKF,&RETURN)==1&&RETURN!=0X9800)//����VS10XX��ʱ��,3��Ƶ ,1.5xADD
    {
        VS1053_SciWrite(VS1053_REG_CLOCKF,0X9800);	//����VS10XX��ʱ��,3��Ƶ ,1.5xADD
        if(retry++>100)return 0;
    }
    HAL_Delay(20);
    return 1;
}

void VS1053_SPK(uint8_t sw)
{
    VS1053_SciWrite(VS1053_REG_WRAMADDR,GPIO_DDR);
    VS1053_SciWrite(VS1053_REG_WRAM,1<<4);
    VS1053_SciWrite(VS1053_REG_WRAMADDR,GPIO_ODATA);
    VS1053_SciWrite(VS1053_REG_WRAM,sw<<4);
}

/* Volume control */
uint8_t VS1053_SetVolume(uint8_t volumeLeft, uint8_t volumeRight)
{
    uint16_t volume;
    volume = ( volumeLeft << 8 ) + volumeRight;

    if(!VS1053_SciWrite(VS1053_REG_VOL, volume)) return 0;
    return 1;
}

/* Mode control */
uint8_t VS1053_SetMode(uint16_t mode)
{
    if(!VS1053_SciWrite(VS1053_REG_MODE, mode)) return 0;
    return 1;
}

uint8_t VS1053_GetMode(uint16_t *mode)
{
    if(!VS1053_SciRead(VS1053_REG_MODE, mode)) return 0;
    return 1;
}

/* Resync control */
uint8_t VS1053_AutoResync()
{
    if(!VS1053_SciWrite(VS1053_REG_WRAMADDR, 0x1E29)) return 0; /* Auto Resync */
    if(!VS1053_SciWrite(VS1053_REG_WRAM, 0)) return 0;
    return 1;
}

/* Set decode time */
uint8_t VS1053_SetDecodeTime(uint16_t time)
{
    if(!VS1053_SciWrite(VS1053_REG_DECODE_TIME, time)) return 0;
    if(!VS1053_SciWrite(VS1053_REG_DECODE_TIME, time)) return 0;
    return 1;
}

/* Send endfill bytes */
uint8_t VS1053_SendEndFill(uint16_t num)
{
    uint16_t regVal;
    if(!VS1053_SciWrite(VS1053_REG_WRAMADDR, 0x1E06)) return 0;	/* endFill */
    if(!VS1053_SciRead(VS1053_REG_WRAM, &regVal)) return 0;
    endFillByte = regVal & 0xFF;

    for(uint16_t i = 0; i < num; i++)
    {
        VS1053_SdiWrite(endFillByte);
    }
    return 1;
}

/* Check DREQ pin */
uint8_t VS1053_IsBusy()
{
    if (HAL_GPIO_ReadPin(VS1053_DREQ_PORT, VS1053_DREQ_PIN) == GPIO_PIN_SET) return 0;  /* Ready */
    else return 1;   /* Busy */
}

/* SCI Tx */
uint8_t VS1053_SciWrite( uint8_t address, uint16_t input )
{
    uint8_t buffer[4];

    buffer[0] = VS1053_WRITE_CMD;
    buffer[1] = address;
    buffer[2] = input >> 8;			/* Input MSB */
    buffer[3] = input & 0x00FF;		/* Input LSB */

    while (HAL_GPIO_ReadPin(VS1053_DREQ_PORT, VS1053_DREQ_PIN) == GPIO_PIN_RESET);	/* Wait DREQ High */

    XCS_LOW;			/* XCS Low */
    if(HAL_SPI_Transmit(HSPI_VS1053, buffer, sizeof(buffer), 10) != HAL_OK) return 0;
    XCS_HIGH;			/* XCS High */

    while (HAL_GPIO_ReadPin(VS1053_DREQ_PORT, VS1053_DREQ_PIN) == GPIO_PIN_RESET);	/* Wait DREQ High */
    return 1;
}

/* SCI TxRx */
uint8_t VS1053_SciRead( uint8_t address, uint16_t *res)
{
    uint8_t dummy = 0xFF;
    uint8_t txBuffer[2];
    uint8_t rxBuffer[2];

    txBuffer[0] = VS1053_READ_CMD;
    txBuffer[1] = address;

    while(HAL_GPIO_ReadPin(VS1053_DREQ_PORT, VS1053_DREQ_PIN) == GPIO_PIN_RESET);	/* Wait DREQ High */

    XCS_LOW;        /* XCS Low */
    if(HAL_SPI_Transmit(HSPI_VS1053, txBuffer, sizeof(txBuffer), 10) != HAL_OK) return 0;
    if(HAL_SPI_TransmitReceive(HSPI_VS1053, &dummy, &rxBuffer[0], 1, 10) != HAL_OK) return 0;
    if(HAL_SPI_TransmitReceive(HSPI_VS1053, &dummy, &rxBuffer[1], 1, 10) != HAL_OK) return 0;
    XCS_HIGH;       /* XCS High */

    *res = rxBuffer[0];     /* Received data */
    *res <<= 8;				/* MSB */
    *res |= rxBuffer[1];	/* LSB */

    while (HAL_GPIO_ReadPin(VS1053_DREQ_PORT, VS1053_DREQ_PIN) == GPIO_PIN_RESET);	/* Wait DREQ High */
    return 1;
}

/* SDI Tx */
uint8_t VS1053_SdiWrite( uint8_t input )
{
    while (HAL_GPIO_ReadPin(VS1053_DREQ_PORT, VS1053_DREQ_PIN) == GPIO_PIN_RESET);	/* Wait DREQ High */

    XDCS_LOW;			/* XDCS Low(SDI) */
    if(HAL_SPI_Transmit(HSPI_VS1053, &input, 1, 10) != HAL_OK) return 0;		/* SPI Tx 1 byte */
    XDCS_HIGH;			/* XDCS High(SDI) */

    return 1;
}




/* SDI Tx 32 bytes */
uint8_t VS1053_SdiWrite32( uint8_t *input32 )
{
    while (HAL_GPIO_ReadPin(VS1053_DREQ_PORT, VS1053_DREQ_PIN) == GPIO_PIN_RESET);	/* Wait DREQ High */

    XDCS_LOW;			/* XDCS Low(SDI) */
    if(HAL_SPI_Transmit(HSPI_VS1053, input32, 32, 10) != HAL_OK) return 0;		/* SPI Tx 32 bytes */
    XDCS_HIGH;			/* XDCS High(SDI) */

    return 1;
}

